package com.example.apptopet;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SocialViewHolder extends RecyclerView.ViewHolder {
    public SocialViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
