package com.example.apptopet;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;

import java.util.Date;

public class MyItem {

    public String nome;
    public int foto;

    public String compromisso;
    public String data;

    public String nomeVacina;
    public String dtVacina;
    public String dtRevacina;
    public String pesoVacina;

    public String nomeRemedio;
    public String dtRemedio;
    public String dtRemedio2;
    public String pesoRemedio;

    public String nomeCompromisso;
    public String nomePet;
    public String dtCompromisso;
    public String dias;

    public Uri fotoSocial;
    public String titulo;
    public String description;
    public int postagem;
    public String tituloFix;

}
