package com.example.apptopet;

import android.graphics.drawable.Drawable;

public class MyItem {
    public String nome;
    public int foto;

    public String compromisso;
    public String data;

    public String nomeVacina;
    public String dtVacina;
    public String dtRevacina;
    public String pesoVacina;

    public String nomeRemedio;
    public String dtRemedio;
    public String dtRemedio2;
    public String pesoRemedio;

    public int foto_social;

    public String nomeCompromisso;
    public String nomePet;
    public String dtCompromisso;
    public String dias;
}
